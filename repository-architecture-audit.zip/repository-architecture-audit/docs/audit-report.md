# Accessibility Audit Report

## Audited website
Replace this with the public website you actually audited.

## Audit method
- Lighthouse accessibility audit
- Keyboard-only navigation check

## Findings

| # | Issue | Evidence | Severity | Remediation | Priority |
|---|---|---|---|---|---|
| 1 | Add the actual finding from Lighthouse | Screenshot 1 | Fill after audit | Fill after audit | Fill after audit |
| 2 | Add the actual finding from Lighthouse | Screenshot 2 | Fill after audit | Fill after audit | Fill after audit |
| 3 | Add the actual finding from Lighthouse | Screenshot 3 | Fill after audit | Fill after audit | Fill after audit |
| 4 | Add the actual finding from Lighthouse | Screenshot 4 | Fill after audit | Fill after audit | Fill after audit |
| 5 | Add the actual finding from Lighthouse | Screenshot 5 | Fill after audit | Fill after audit | Fill after audit |

> Do not invent findings. Replace the placeholders with the five issues and screenshots from your real audit.
