# Repository Architecture Audit

## Overview
This repository contains the project skeleton and accessibility audit required for the Repository Architecture Audit task.

## Architecture

```text
repository-architecture-audit/
├── client/       # Frontend/client code
├── server/       # Backend/server code
├── docs/         # Audit report and project documentation
├── test/         # Automated tests
├── screenshots/  # Lighthouse and keyboard-audit evidence
└── README.md     # Project documentation
```

## Audit
A public-facing website is audited using:
1. Lighthouse accessibility checks
2. Keyboard-only navigation

The final audit report is in `docs/audit-report.md`.

## Local setup
1. Clone or download the repository.
2. Open the project folder in VS Code.
3. Open `client/index.html` in a browser.
4. Add the server implementation in `server/`.
5. Add tests in `test/`.

## First vertical feature slice
The first feature slice will connect a client page to a server endpoint and display the returned result in the client.

## Evidence
Place the actual Lighthouse and keyboard-navigation screenshots in `screenshots/` and reference them in the audit report.
